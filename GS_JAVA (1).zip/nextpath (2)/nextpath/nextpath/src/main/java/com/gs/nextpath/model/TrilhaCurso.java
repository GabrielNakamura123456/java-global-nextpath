package com.gs.nextpath.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TRILHA_CURSO_NEXTPATH")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrilhaCurso {

    @EmbeddedId
    private TrilhaCursoId id = new TrilhaCursoId();

    @ManyToOne
    @MapsId("idTrilha")
    @JoinColumn(name = "ID_TRILHA")
    private Trilha trilha;

    @ManyToOne
    @MapsId("idCurso")
    @JoinColumn(name = "ID_CURSO")
    private Curso curso;
}
