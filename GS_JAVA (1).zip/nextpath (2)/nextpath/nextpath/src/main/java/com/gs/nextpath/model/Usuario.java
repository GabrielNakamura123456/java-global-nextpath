package com.gs.nextpath.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Table(name = "USUARIO_NEXTPATH")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Usuario {

    @Id
    @SequenceGenerator(name = "usuario_seq", sequenceName = "SEQ_USUARIO_NEXTPATH", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "usuario_seq")
    @Column(name = "ID_USUARIO")
    private Long id;

    @NotBlank
    @Size(max = 100)
    private String nome;

    @Email
    @NotBlank
    @Size(max = 100)
    private String email;

    @NotBlank
    @Size(min = 6)
    private String senha;

    @NotBlank
    private String tipo;

    private String areaInteresse;

    private String nivel;
}
