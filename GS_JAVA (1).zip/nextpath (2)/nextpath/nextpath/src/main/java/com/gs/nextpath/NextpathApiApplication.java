package com.gs.nextpath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NextpathApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(NextpathApiApplication.class, args);
    }
}
