package com.gs.nextpath.controller;

import com.gs.nextpath.model.Curso;
import com.gs.nextpath.service.CursoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cursos")
@RequiredArgsConstructor
public class CursoController {

    private final CursoService cursoService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Curso criar(@Valid @RequestBody Curso curso) {
        return cursoService.salvar(curso);
    }

    @GetMapping
    public Page<Curso> listar(
            @PageableDefault(size = 10, sort = "titulo", direction = Sort.Direction.ASC)
            Pageable pageable
    ) {
        return cursoService.listar(pageable);
    }
}
