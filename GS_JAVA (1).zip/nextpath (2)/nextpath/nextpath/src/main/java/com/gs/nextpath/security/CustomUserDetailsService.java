package com.gs.nextpath.security;

import com.gs.nextpath.model.Usuario;
import com.gs.nextpath.repository.UsuarioRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Usuario usuario = usuarioRepository.findByEmail(username)
                .orElseThrow(() ->
                        new UsernameNotFoundException("Usuário não encontrado: " + username));

        if (usuario.getSenha() == null || usuario.getSenha().isBlank()) {
            throw new UsernameNotFoundException("Usuário sem senha cadastrada: " + username);
        }

        // Converte tipo -> ROLE_TIPO (ex.: tipo = "ADMIN" → ROLE_ADMIN)
        String role = "ROLE_" + usuario.getTipo().trim().toUpperCase();

        return User.builder()
                .username(usuario.getEmail())
                .password(usuario.getSenha()) // precisa estar bcrypt
                .authorities(List.of(new SimpleGrantedAuthority(role)))
                .build();
    }
}
