package com.gs.nextpath.controller;

import com.gs.nextpath.model.Trilha;
import com.gs.nextpath.service.TrilhaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trilhas")
@RequiredArgsConstructor
public class TrilhaController {

    private final TrilhaService trilhaService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Trilha criar(@Valid @RequestBody Trilha trilha) {
        return trilhaService.salvar(trilha);
    }

    @GetMapping
    public Page<Trilha> listar(
            @PageableDefault(size = 10, sort = "nome", direction = Sort.Direction.ASC)
            Pageable pageable
    ) {
        return trilhaService.listar(pageable);
    }
}
