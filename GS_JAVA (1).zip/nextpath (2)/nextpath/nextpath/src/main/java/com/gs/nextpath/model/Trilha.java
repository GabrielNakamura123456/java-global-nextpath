package com.gs.nextpath.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Table(name = "TRILHA_NEXTPATH")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Trilha {

    @Id
    @SequenceGenerator(name = "trilha_seq", sequenceName = "SEQ_TRILHA_NEXTPATH", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trilha_seq")
    @Column(name = "ID_TRILHA")
    private Long id;

    @NotBlank
    @Size(max = 200)
    @Column(name = "NOME", nullable = false)
    private String nome;

    @Size(max = 500)
    @Column(name = "DESCRICAO")
    private String descricao;

    @Size(max = 100)
    @Column(name = "AREA")
    private String area;

    @Size(max = 20)
    @Column(name = "NIVEL_ALVO")
    private String nivelAlvo;
}
