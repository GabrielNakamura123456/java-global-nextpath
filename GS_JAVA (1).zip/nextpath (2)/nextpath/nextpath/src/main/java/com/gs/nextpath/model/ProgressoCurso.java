package com.gs.nextpath.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "PROGRESSO_CURSO_NEXTPATH")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProgressoCurso {

    @EmbeddedId
    private ProgressoCursoId id = new ProgressoCursoId();

    @ManyToOne
    @MapsId("idUsuario")
    @JoinColumn(name = "ID_USUARIO")
    private Usuario usuario;

    @ManyToOne
    @MapsId("idCurso")
    @JoinColumn(name = "ID_CURSO")
    private Curso curso;

    @Column(name = "STATUS", length = 20)
    private String status;

    @Column(name = "DATA_ATUALIZACAO")
    private LocalDate dataAtualizacao;
}
