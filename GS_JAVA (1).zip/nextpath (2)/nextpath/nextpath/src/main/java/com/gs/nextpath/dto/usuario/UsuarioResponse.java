package com.gs.nextpath.dto.usuario;

import lombok.*;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor @Builder
public class UsuarioResponse {
    private Long id;
    private String nome;
    private String email;
    private String tipo;
    private String areaInteresse;
    private String nivel;
}
