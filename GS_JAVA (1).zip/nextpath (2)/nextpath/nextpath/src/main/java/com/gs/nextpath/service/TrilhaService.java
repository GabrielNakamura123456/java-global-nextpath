package com.gs.nextpath.service;

import com.gs.nextpath.model.Trilha;
import com.gs.nextpath.repository.TrilhaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class TrilhaService {

    private final TrilhaRepository trilhaRepository;

    @Transactional
    public Trilha salvar(Trilha trilha) {
        return trilhaRepository.save(trilha);
    }

    @Transactional(readOnly = true)
    public Page<Trilha> listar(Pageable pageable) {
        return trilhaRepository.findAll(pageable);
    }
}
