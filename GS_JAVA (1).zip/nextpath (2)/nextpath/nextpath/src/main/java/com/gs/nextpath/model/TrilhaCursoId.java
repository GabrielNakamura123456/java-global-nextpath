package com.gs.nextpath.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TrilhaCursoId implements Serializable {

    @Column(name = "ID_TRILHA")
    private Long idTrilha;

    @Column(name = "ID_CURSO")
    private Long idCurso;
}
