package com.gs.nextpath.service;

import com.gs.nextpath.dto.usuario.UsuarioRequest;
import com.gs.nextpath.dto.usuario.UsuarioResponse;
import com.gs.nextpath.model.Usuario;
import com.gs.nextpath.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Transactional
    public UsuarioResponse criar(UsuarioRequest request) {

        Usuario usuario = Usuario.builder()
                .nome(request.getNome())
                .email(request.getEmail())
                .senha(request.getSenha())
                .tipo(request.getTipo())
                .areaInteresse(request.getAreaInteresse())
                .nivel(request.getNivel())
                .build();

        usuario = usuarioRepository.save(usuario);

        return UsuarioResponse.builder()
                .id(usuario.getId())
                .nome(usuario.getNome())
                .email(usuario.getEmail())
                .tipo(usuario.getTipo())
                .areaInteresse(usuario.getAreaInteresse())
                .nivel(usuario.getNivel())
                .build();
    }

    @Transactional(readOnly = true)
    public Page<UsuarioResponse> listar(String nivel, String areaInteresse, Pageable pageable) {

        Page<Usuario> page;

        if (nivel != null && !nivel.isBlank()) {
            page = usuarioRepository.findByNivelIgnoreCase(nivel, pageable);
        } else if (areaInteresse != null && !areaInteresse.isBlank()) {
            page = usuarioRepository.findByAreaInteresseIgnoreCase(areaInteresse, pageable);
        } else {
            page = usuarioRepository.findAll(pageable);
        }

        return page.map(usuario ->
                UsuarioResponse.builder()
                        .id(usuario.getId())
                        .nome(usuario.getNome())
                        .email(usuario.getEmail())
                        .tipo(usuario.getTipo())
                        .areaInteresse(usuario.getAreaInteresse())
                        .nivel(usuario.getNivel())
                        .build()
        );
    }
}
