package com.gs.nextpath.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "CURSO_NEXTPATH")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Curso {

    @Id
    @SequenceGenerator(name = "curso_seq", sequenceName = "SEQ_CURSO_NEXTPATH", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "curso_seq")
    @Column(name = "ID_CURSO")
    private Long id;

    @Column(name = "TITULO", nullable = false)
    private String titulo;

    @Column(name = "DESCRICAO")
    private String descricao;

    @Column(name = "CARGA_HORARIA", nullable = false)
    private Integer cargaHoraria;

    @Column(name = "AREA")
    private String area;

    @Column(name = "NIVEL")
    private String nivel;

    @Column(name = "LINK_AULA")
    private String linkAula;
}
