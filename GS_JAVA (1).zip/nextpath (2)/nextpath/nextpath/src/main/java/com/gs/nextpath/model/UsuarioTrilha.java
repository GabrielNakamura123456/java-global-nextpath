package com.gs.nextpath.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "USUARIO_TRILHA_NEXTPATH")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UsuarioTrilha {

    @EmbeddedId
    private UsuarioTrilhaId id = new UsuarioTrilhaId();

    @ManyToOne
    @MapsId("idUsuario")
    @JoinColumn(name = "ID_USUARIO")
    private Usuario usuario;

    @ManyToOne
    @MapsId("idTrilha")
    @JoinColumn(name = "ID_TRILHA")
    private Trilha trilha;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "DATA_INICIO")
    private LocalDate dataInicio;

    @Column(name = "DATA_FIM")
    private LocalDate dataFim;
}
