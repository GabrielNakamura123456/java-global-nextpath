package com.gs.nextpath.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.SignatureAlgorithm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.Objects;

@Service
public class JwtService {

    private final Key key;
    private final long expirationMillis;

    public JwtService(
            @Value("${security.jwt.secret}") String secretBase64,
            @Value("${security.jwt.expiration:86400000}") long expirationMillis) {

        if (secretBase64 == null || secretBase64.isBlank()) {
            throw new IllegalArgumentException("Propriedade 'security.jwt.secret' não pode ser nula ou vazia. Deve ser uma chave em Base64.");
        }

        byte[] keyBytes;
        try {
            keyBytes = Decoders.BASE64.decode(secretBase64);
        } catch (Exception ex) {
            throw new IllegalArgumentException("A propriedade 'security.jwt.secret' deve ser uma string Base64 válida.", ex);
        }

        this.key = Keys.hmacShaKeyFor(keyBytes);
        this.expirationMillis = expirationMillis;
    }

    public String generateToken(String subject) {
        Objects.requireNonNull(subject, "subject não pode ser nulo");

        Date now = new Date();
        Date exp = new Date(now.getTime() + expirationMillis);

        return Jwts.builder()
                .setSubject(subject)
                .setIssuedAt(now)
                .setExpiration(exp)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
            return true;
        } catch (Exception ex) {
            // opcional: log.warn("Token inválido: {}", ex.getMessage());
            return false;
        }
    }

    public String getSubject(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();
        } catch (Exception ex) {
            return null;
        }
    }
}
