package com.gs.nextpath.repository;

import com.gs.nextpath.model.Trilha;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrilhaRepository extends JpaRepository<Trilha, Long> {
}
