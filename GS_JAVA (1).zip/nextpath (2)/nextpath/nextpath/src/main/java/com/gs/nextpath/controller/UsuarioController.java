package com.gs.nextpath.controller;

import com.gs.nextpath.dto.usuario.UsuarioRequest;
import com.gs.nextpath.dto.usuario.UsuarioResponse;
import com.gs.nextpath.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioResponse criar(@RequestBody UsuarioRequest request) { // <- sem @Valid
        return usuarioService.criar(request);
    }


    @GetMapping
    public Page<UsuarioResponse> listar(
            @RequestParam(required = false) String nivel,
            @RequestParam(required = false) String areaInteresse,
            @PageableDefault(size = 10, sort = "nome", direction = Sort.Direction.ASC)
            Pageable pageable
    ) {
        return usuarioService.listar(nivel, areaInteresse, pageable);
    }
}
